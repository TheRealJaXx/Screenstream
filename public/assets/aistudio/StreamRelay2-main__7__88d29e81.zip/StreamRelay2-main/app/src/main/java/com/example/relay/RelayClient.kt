package com.example.relay

import android.graphics.Bitmap
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.os.Build
import android.os.SystemClock
import android.view.SurfaceHolder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.IOException
import java.net.ConnectException
import java.net.InetSocketAddress
import java.net.Socket
import java.net.SocketTimeoutException
import java.util.ArrayDeque
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

enum class RxConnectionState {
    DISCONNECTED,
    CONNECTING,
    CONNECTED,
    RECONNECTING
}

enum class AudioLatencyProfile(val label: String, val targetMinMs: Int, val capMaxMs: Int) {
    GAME("Game (30/120 ms)", 30, 120),
    BALANCED("Balanced (50/180 ms)", 50, 180),
    SMOOTH("Smooth (80/260 ms)", 80, 260)
}

data class RxStats(
    val videoPacketsReceived: Long = 0L,
    val videoBytesPerSecond: Long = 0L,
    val audioPacketsReceived: Long = 0L,
    val secondsSinceLastVideoPacket: Float = 0f,
    val decodeSuccesses: Long = 0L,
    val decodeFailures: Long = 0L,
    val lastDecodeError: String = "None",
    val lastFrameFirst4BytesHex: String = "--",
    val lastFrameEndsEoi: Boolean = false,
    val decodedBitmapSize: String = "--",
    val fps: Float = 0f,
    val decodeTimeMs: Long = 0L,
    val decodeTimeMsAvg: Float = 0f,
    val decodeTimeMsMax: Long = 0L,
    val frameAgeMs: Float = 0f,
    val arrivalIntervalP95Ms: Float = 0f,
    val droppedFrames: Long = 0L,
    val rttAvgMs: Float = 0f,
    val rttP95Ms: Float = 0f,
    val audioUnderrunCount: Int = 0,
    val frameSizeBytes: Int = 0,
    val statusDetail: String = "Disconnected",
    val videoCodec: String = "MJPEG"
)

class RelayClient(
    private val onLog: (tag: String, message: String, isError: Boolean) -> Unit
) {
    companion object {
        const val SAMPLE_RATE = 48000
        const val CHANNEL_CONFIG_OUT = AudioFormat.CHANNEL_OUT_STEREO
        const val AUDIO_FORMAT = AudioFormat.ENCODING_PCM_16BIT

        // 1 ms of 48kHz stereo 16-bit = 48 * 4 = 192 bytes
        // 20ms chunk = 3840 bytes
        const val BYTES_PER_MS = 192
        const val SILENCE_CHUNK_BYTES = BYTES_PER_MS * 20 // 3840 bytes
        const val COMFORT_SILENCE_BYTES = BYTES_PER_MS * 5 // 960 bytes (5ms)
    }

    private val clientScope = CoroutineScope(Dispatchers.IO)
    private var videoJob: Job? = null
    private var audioJob: Job? = null
    private var rttJob: Job? = null
    private var audioPlaybackJob: Job? = null
    private var statsJob: Job? = null

    private val isRunning = AtomicBoolean(false)
    private val isManuallyStopped = AtomicBoolean(false)

    @Volatile
    private var videoSocket: Socket? = null

    @Volatile
    private var audioSocket: Socket? = null

    val isVideoConnected: Boolean
        get() = isVideoSocketConnected

    val isAudioConnected: Boolean
        get() = isAudioSocketConnected

    @Volatile
    private var isVideoSocketConnected = false

    @Volatile
    private var isAudioSocketConnected = false

    private val connectionGeneration = AtomicInteger(0)

    private val _connectionState = MutableStateFlow(RxConnectionState.DISCONNECTED)
    val connectionState: StateFlow<RxConnectionState> = _connectionState.asStateFlow()

    private val _stats = MutableStateFlow(RxStats())
    val stats: StateFlow<RxStats> = _stats.asStateFlow()

    // Dedicated MjpegPlayer instance
    private val mjpegPlayer = MjpegPlayer { tag, msg, err -> onLog(tag, msg, err) }
    val currentBitmap: StateFlow<Bitmap?> = mjpegPlayer.currentBitmap

    // Audio Playback Engine
    private var audioTrack: AudioTrack? = null
    private val _isAudioPlaying = MutableStateFlow(false)
    val isAudioPlaying: StateFlow<Boolean> = _isAudioPlaying.asStateFlow()

    private val _isMuted = MutableStateFlow(false)
    val isMuted: StateFlow<Boolean> = _isMuted.asStateFlow()

    private val _audioLatencyProfile = MutableStateFlow(AudioLatencyProfile.BALANCED)
    val audioLatencyProfile: StateFlow<AudioLatencyProfile> = _audioLatencyProfile.asStateFlow()

    private val _audioDelayMs = MutableStateFlow(0)
    val audioDelayMs: StateFlow<Int> = _audioDelayMs.asStateFlow()

    // Jitter buffer queue
    private val audioJitterLock = Object()
    private val audioJitterQueue = ArrayDeque<ByteArray>()
    private var audioJitterBufferedBytes = 0

    // RTT measurements
    private val rttSamplesMs = ArrayList<Float>(35)
    private var rttAvgMs = 0f
    private var rttP95Ms = 0f

    // Diagnostics & Counters
    private var videoPacketsCount = 0L
    private var audioPacketsCount = 0L
    private var videoBytesCounter = 0L
    private var lastBytesSecondTimestamp = SystemClock.elapsedRealtime()
    private var currentBytesPerSec = 0L
    private var lastVideoPacketTimestamp = 0L
    private var statusDetailMessage = "Disconnected"

    init {
        // Collect MjpegPlayer stats and update unified RxStats
        clientScope.launch {
            while (true) {
                delay(1000)
                updateStatsState()
            }
        }
    }

    fun setMuted(muted: Boolean) {
        _isMuted.value = muted
        if (muted) {
            synchronized(audioJitterLock) {
                audioJitterQueue.clear()
                audioJitterBufferedBytes = 0
                audioJitterLock.notifyAll()
            }
        }
    }

    fun setAudioLatencyProfile(profile: AudioLatencyProfile) {
        _audioLatencyProfile.value = profile
    }

    fun setAudioDelayMs(delayMs: Int) {
        _audioDelayMs.value = delayMs.coerceIn(0, 200)
    }

    // Surface & Hardware H.264 Decoder
    private var attachedSurfaceHolder: SurfaceHolder? = null
    private var h264Decoder: HardwareH264Decoder? = null
    private var activeVideoCodec = "MJPEG"
    private var h264FrameCountInSecond = 0
    private var h264Fps = 0f
    private var lastH264FpsCalcTime = SystemClock.elapsedRealtime()
    private var lastH264FrameSizeBytes = 0

    fun attachSurface(holder: SurfaceHolder) {
        attachedSurfaceHolder = holder
        mjpegPlayer.attachSurface(holder)
        if (activeVideoCodec == "H.264" && holder.surface.isValid) {
            try {
                h264Decoder?.release()
                h264Decoder = HardwareH264Decoder(1280, 720, holder.surface).also { it.start() }
            } catch (e: Exception) {
                onLog("RX-Relay", "Error attaching H.264 surface: ${e.message}", true)
            }
        }
    }

    fun detachSurface(holder: SurfaceHolder? = null) {
        attachedSurfaceHolder = null
        try { h264Decoder?.release() } catch (_: Exception) {}
        h264Decoder = null
        mjpegPlayer.detachSurface()
    }

    fun connect(host: String, port: Int) {
        val gen = connectionGeneration.incrementAndGet()
        isManuallyStopped.set(false)
        isRunning.set(true)
        _connectionState.value = RxConnectionState.CONNECTING
        statusDetailMessage = "Starting connections to $host:$port..."

        synchronized(audioJitterLock) {
            audioJitterQueue.clear()
            audioJitterBufferedBytes = 0
        }

        // Cancel previous jobs
        videoJob?.cancel()
        audioJob?.cancel()
        rttJob?.cancel()
        audioPlaybackJob?.cancel()

        try { videoSocket?.close() } catch (_: Exception) {}
        try { audioSocket?.close() } catch (_: Exception) {}

        startAudioPlaybackThread(gen)
        startRttProbe(host, port, gen)

        videoJob = clientScope.launch {
            runVideoLoop(host, port, gen)
        }

        audioJob = clientScope.launch {
            runAudioLoop(host, port + 1, gen)
        }
    }

    fun disconnect() {
        isManuallyStopped.set(true)
        isRunning.set(false)
        connectionGeneration.incrementAndGet()

        videoJob?.cancel()
        audioJob?.cancel()
        rttJob?.cancel()
        audioPlaybackJob?.cancel()

        try { videoSocket?.close() } catch (_: Exception) {}
        try { audioSocket?.close() } catch (_: Exception) {}
        videoSocket = null
        audioSocket = null
        isVideoSocketConnected = false
        isAudioSocketConnected = false

        try { h264Decoder?.release() } catch (_: Exception) {}
        h264Decoder = null
        releaseAudioTrack()

        synchronized(audioJitterLock) {
            audioJitterQueue.clear()
            audioJitterBufferedBytes = 0
            audioJitterLock.notifyAll()
        }

        _connectionState.value = RxConnectionState.DISCONNECTED
        statusDetailMessage = "Disconnected"
        updateStatsState(force = true)
        onLog("RX-Relay", "Client disconnected completely", false)
    }

    private suspend fun runVideoLoop(host: String, port: Int, gen: Int) {
        while (isRunning.get() && !isManuallyStopped.get() && gen == connectionGeneration.get()) {
            var socket: Socket? = null
            try {
                statusDetailMessage = "Connecting to Video ($host:$port)..."
                updateStatsState(force = true)

                val s = Socket()
                s.tcpNoDelay = true
                s.sendBufferSize = 64 * 1024
                s.receiveBufferSize = 64 * 1024 // 64 KB SO_RCVBUF
                try {
                    s.setPerformancePreferences(0, 2, 1)
                } catch (_: Exception) {}
                s.connect(InetSocketAddress(host, port), 4000)

                if (gen != connectionGeneration.get() || !isRunning.get()) {
                    try { s.close() } catch (_: Exception) {}
                    break
                }

                socket = s
                videoSocket = s
                isVideoSocketConnected = true
                _connectionState.value = RxConnectionState.CONNECTED
                statusDetailMessage = "Connected (Video :$port, Audio :${port + 1})"
                onLog("RX-Relay", "Video socket connected to $host:$port", false)
                updateStatsState(force = true)

                val bufferedIn = BufferedInputStream(s.getInputStream(), 32 * 1024)
                val inputStream = DataInputStream(bufferedIn)

                while (isRunning.get() && gen == connectionGeneration.get() && !s.isClosed && s.isConnected) {
                    // 16-byte big-endian header: magic (4B) + length (4B) + seq (4B) + flags (4B)
                    val magic = inputStream.readInt()
                    if (magic != RelayServer.VIDEO_FRAME_MAGIC) {
                        throw IOException("Header magic mismatch: 0x%08X (expected 0x%08X). Reconnecting...".format(magic, RelayServer.VIDEO_FRAME_MAGIC))
                    }

                    val length = inputStream.readInt()
                    if (length <= 0 || length > 10_000_000) {
                        throw IOException("Invalid video frame length received: $length")
                    }

                    val seq = inputStream.readInt()
                    val flags = inputStream.readInt() // 0 = MJPEG, 1 = H.264

                    val arrivalNs = System.nanoTime()
                    videoPacketsCount++
                    videoBytesCounter += length + 16
                    lastVideoPacketTimestamp = SystemClock.elapsedRealtime()

                    if (flags == 1) {
                        activeVideoCodec = "H.264"
                        h264FrameCountInSecond++
                        lastH264FrameSizeBytes = length
                        val nal = ByteArray(length)
                        inputStream.readFully(nal, 0, length)

                        val holder = attachedSurfaceHolder
                        if (holder != null && holder.surface.isValid) {
                            if (h264Decoder == null) {
                                try {
                                    h264Decoder = HardwareH264Decoder(1280, 720, holder.surface).also { it.start() }
                                    onLog("RX-Relay", "Hardware H.264 Decoder engaged for direct surface render", false)
                                } catch (e: Exception) {
                                    onLog("RX-Relay", "Failed to start H.264 decoder: ${e.message}", true)
                                }
                            }
                            h264Decoder?.decodeNal(nal)
                        }
                    } else {
                        activeVideoCodec = "MJPEG"
                        if (h264Decoder != null) {
                            try { h264Decoder?.release() } catch (_: Exception) {}
                            h264Decoder = null
                        }
                        val buffer = mjpegPlayer.acquireBuffer(length)
                        inputStream.readFully(buffer, 0, length)
                        mjpegPlayer.submit(buffer, length, seq, arrivalNs)
                    }
                }
            } catch (e: SocketTimeoutException) {
                statusDetailMessage = "Connect timed out (wrong IP / different network / client isolation)"
                onLog("RX-Relay", "Video connect timeout: ${e.message}", true)
            } catch (e: ConnectException) {
                statusDetailMessage = "Connection refused (TX not running or wrong port)"
                onLog("RX-Relay", "Video connection refused: ${e.message}", true)
            } catch (e: Exception) {
                if (!isManuallyStopped.get() && gen == connectionGeneration.get()) {
                    statusDetailMessage = "Video error: ${e.message ?: "Connection closed"}"
                    onLog("RX-Relay", "Video connection exception: ${e.message}", false)
                }
            } finally {
                isVideoSocketConnected = false
                try { socket?.close() } catch (_: Exception) {}
                if (gen == connectionGeneration.get()) {
                    videoSocket = null
                }
            }

            if (!isManuallyStopped.get() && gen == connectionGeneration.get()) {
                _connectionState.value = RxConnectionState.RECONNECTING
                updateStatsState(force = true)
                delay(2000)
            } else {
                break
            }
        }
    }

    private suspend fun runAudioLoop(host: String, port: Int, gen: Int) {
        while (isRunning.get() && !isManuallyStopped.get() && gen == connectionGeneration.get()) {
            var socket: Socket? = null
            try {
                val s = Socket()
                s.tcpNoDelay = true
                try { s.trafficClass = 0x10 } catch (_: Exception) {} // IPTOS_LOWDELAY
                s.sendBufferSize = 64 * 1024
                s.receiveBufferSize = 64 * 1024
                s.connect(InetSocketAddress(host, port), 4000)

                if (gen != connectionGeneration.get() || !isRunning.get()) {
                    try { s.close() } catch (_: Exception) {}
                    break
                }

                socket = s
                audioSocket = s
                isAudioSocketConnected = true
                onLog("RX-Relay", "Audio socket connected to $host:$port", false)

                val inputStream = DataInputStream(BufferedInputStream(s.getInputStream(), 16 * 1024))

                while (isRunning.get() && gen == connectionGeneration.get() && !s.isClosed && s.isConnected) {
                    val length = inputStream.readInt()
                    if (length <= 0 || length > 100_000) {
                        throw IOException("Invalid audio chunk length received: $length")
                    }

                    val pcmBytes = ByteArray(length)
                    inputStream.readFully(pcmBytes)

                    audioPacketsCount++

                    val profile = _audioLatencyProfile.value
                    val delayMs = _audioDelayMs.value
                    val capMaxBytes = (profile.capMaxMs + delayMs) * BYTES_PER_MS
                    val hardCapBytes = maxOf(capMaxBytes * 2, capMaxBytes + 3840 * 2)

                    // Push to jitter buffer and notify playback thread immediately
                    synchronized(audioJitterLock) {
                        audioJitterQueue.addLast(pcmBytes)
                        audioJitterBufferedBytes += pcmBytes.size

                        // Hard cap to avoid unbounded backlog during long Wi-Fi stalls
                        while (audioJitterBufferedBytes > hardCapBytes && audioJitterQueue.isNotEmpty()) {
                            val dropped = audioJitterQueue.pollFirst()
                            if (dropped != null) {
                                audioJitterBufferedBytes -= dropped.size
                            }
                        }
                        audioJitterLock.notify()
                    }
                }
            } catch (e: Exception) {
                if (!isManuallyStopped.get() && gen == connectionGeneration.get()) {
                    onLog("RX-Relay", "Audio socket note: ${e.message}", false)
                }
            } finally {
                isAudioSocketConnected = false
                try { socket?.close() } catch (_: Exception) {}
                if (gen == connectionGeneration.get()) {
                    audioSocket = null
                }
            }

            if (!isManuallyStopped.get() && gen == connectionGeneration.get()) {
                delay(2000)
            } else {
                break
            }
        }
    }

    private fun startRttProbe(host: String, port: Int, gen: Int) {
        rttJob?.cancel()
        rttJob = clientScope.launch {
            val rttPort = port + 2
            while (isRunning.get() && !isManuallyStopped.get() && gen == connectionGeneration.get()) {
                var socket: Socket? = null
                try {
                    val s = Socket()
                    s.tcpNoDelay = true
                    s.connect(InetSocketAddress(host, rttPort), 3000)
                    socket = s
                    val dout = DataOutputStream(BufferedOutputStream(s.getOutputStream(), 1024))
                    val din = DataInputStream(BufferedInputStream(s.getInputStream(), 1024))

                    while (isRunning.get() && gen == connectionGeneration.get() && !s.isClosed && s.isConnected) {
                        val sentNs = System.nanoTime()
                        dout.writeLong(sentNs)
                        dout.flush()

                        val echoedNs = din.readLong()
                        val rttMs = (System.nanoTime() - echoedNs) / 1_000_000f
                        if (rttMs in 0.05f..1000f) {
                            synchronized(rttSamplesMs) {
                                rttSamplesMs.add(rttMs)
                                if (rttSamplesMs.size > 30) {
                                    rttSamplesMs.removeAt(0)
                                }
                                rttAvgMs = (rttSamplesMs.average().toFloat() * 10f).let { Math.round(it) / 10f }
                                val sorted = rttSamplesMs.sorted()
                                val p95Idx = ((sorted.size - 1) * 0.95f).toInt()
                                rttP95Ms = (sorted[p95Idx] * 10f).let { Math.round(it) / 10f }
                            }
                        }
                        delay(500)
                    }
                } catch (_: Exception) {
                } finally {
                    try { socket?.close() } catch (_: Exception) {}
                }
                delay(2000)
            }
        }
    }

    private fun startAudioPlaybackThread(gen: Int) {
        audioPlaybackJob?.cancel()
        audioPlaybackJob = clientScope.launch(Dispatchers.Default) {
            try {
                android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_URGENT_AUDIO)
            } catch (_: Exception) {}

            initAudioTrack()
            val track = audioTrack ?: return@launch
            val comfortSilence = ByteArray(COMFORT_SILENCE_BYTES)
            var isPrebuffering = true
            var starvationCount = 0

            while (isActive && isRunning.get() && gen == connectionGeneration.get()) {
                val profile = _audioLatencyProfile.value
                val delayMs = _audioDelayMs.value
                val targetMinBytes = (profile.targetMinMs + delayMs) * BYTES_PER_MS
                val capMaxBytes = (profile.capMaxMs + delayMs) * BYTES_PER_MS

                var chunkToPlay: ByteArray? = null

                synchronized(audioJitterLock) {
                    if (isPrebuffering) {
                        if (audioJitterBufferedBytes >= targetMinBytes) {
                            isPrebuffering = false
                            chunkToPlay = audioJitterQueue.pollFirst()
                            chunkToPlay?.let { audioJitterBufferedBytes -= it.size }
                        } else {
                            try {
                                audioJitterLock.wait(10)
                            } catch (_: InterruptedException) {}
                        }
                    } else {
                        chunkToPlay = audioJitterQueue.pollFirst()
                        if (chunkToPlay != null) {
                            audioJitterBufferedBytes -= chunkToPlay.size
                        } else {
                            // Queue temporarily dry — wait up to 4ms for next TCP audio chunk
                            try {
                                audioJitterLock.wait(4)
                            } catch (_: InterruptedException) {}
                            chunkToPlay = audioJitterQueue.pollFirst()
                            chunkToPlay?.let { audioJitterBufferedBytes -= it.size }
                        }
                    }

                    // Enforce cap when buffer has accumulated beyond capMaxBytes + 1 frame headroom
                    while (audioJitterBufferedBytes > (capMaxBytes + 3840) && audioJitterQueue.size > 2) {
                        val dropped = audioJitterQueue.pollFirst()
                        if (dropped != null) {
                            audioJitterBufferedBytes -= dropped.size
                        }
                    }
                }

                if (chunkToPlay != null) {
                    starvationCount = 0
                    if (!_isMuted.value) {
                        track.write(chunkToPlay, 0, chunkToPlay.size)
                    }
                    if (!_isAudioPlaying.value) {
                        _isAudioPlaying.value = true
                    }
                } else if (!isPrebuffering) {
                    starvationCount++
                    // Only write 5ms comfort silence if starved for >20ms to prevent DAC pop
                    if (starvationCount > 4) {
                        if (!_isMuted.value) {
                            track.write(comfortSilence, 0, comfortSilence.size)
                        }
                        starvationCount = 0
                    }
                }
            }
        }
    }

    private fun initAudioTrack() {
        try {
            val minBuf = maxOf(
                AudioTrack.getMinBufferSize(SAMPLE_RATE, CHANNEL_CONFIG_OUT, AUDIO_FORMAT),
                (SAMPLE_RATE * 4) / 20
            )
            val attributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build()
            val format = AudioFormat.Builder()
                .setEncoding(AUDIO_FORMAT)
                .setSampleRate(SAMPLE_RATE)
                .setChannelMask(CHANNEL_CONFIG_OUT)
                .build()

            val track = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                AudioTrack.Builder()
                    .setAudioAttributes(attributes)
                    .setAudioFormat(format)
                    .setBufferSizeInBytes(minBuf)
                    .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
                    .build()
            } else {
                AudioTrack(
                    attributes,
                    format,
                    minBuf,
                    AudioTrack.MODE_STREAM,
                    AudioManager.AUDIO_SESSION_ID_GENERATE
                )
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                try {
                    track.setBufferSizeInFrames(minBuf / 4)
                } catch (_: Exception) {}
            }

            if (track.state == AudioTrack.STATE_INITIALIZED) {
                track.play()
                audioTrack = track
            } else {
                track.release()
                onLog("RX-Audio", "AudioTrack failed to initialize (state != STATE_INITIALIZED)", true)
            }
        } catch (e: Exception) {
            onLog("RX-Audio", "Failed to initialize AudioTrack: ${e.message}", true)
        }
    }

    private fun releaseAudioTrack() {
        try {
            audioTrack?.stop()
            audioTrack?.release()
        } catch (_: Exception) {}
        audioTrack = null
        _isAudioPlaying.value = false
    }

    private fun updateStatsState(force: Boolean = false) {
        val now = SystemClock.elapsedRealtime()
        if (now - lastBytesSecondTimestamp >= 1000L) {
            val elapsedSec = (now - lastBytesSecondTimestamp) / 1000f
            currentBytesPerSec = if (elapsedSec > 0f) (videoBytesCounter / elapsedSec).toLong() else 0L
            videoBytesCounter = 0L
            lastBytesSecondTimestamp = now
        }

        val isH264 = activeVideoCodec == "H.264"
        if (now - lastH264FpsCalcTime >= 1000L) {
            val elapsed = (now - lastH264FpsCalcTime) / 1000f
            h264Fps = if (elapsed > 0f) h264FrameCountInSecond / elapsed else 0f
            h264FrameCountInSecond = 0
            lastH264FpsCalcTime = now
        }

        val sinceLastVideo = if (lastVideoPacketTimestamp > 0L) {
            (now - lastVideoPacketTimestamp) / 1000f
        } else 0f

        val playerStats = mjpegPlayer.stats.value

        val underruns = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            try { audioTrack?.underrunCount ?: 0 } catch (_: Exception) { 0 }
        } else 0

        val effectiveFps = if (isH264) ((h264Fps * 10f).let { Math.round(it) / 10f }) else playerStats.fps
        val effectiveFrameSize = if (isH264) lastH264FrameSizeBytes else playerStats.lastFrameSizeBytes
        val effectiveResolution = if (isH264) "720p (H.264)" else if (playerStats.resolution.isNotEmpty()) playerStats.resolution else "--"

        _stats.value = RxStats(
            videoPacketsReceived = videoPacketsCount,
            videoBytesPerSecond = currentBytesPerSec,
            audioPacketsReceived = audioPacketsCount,
            secondsSinceLastVideoPacket = (sinceLastVideo * 10f).let { Math.round(it) / 10f },
            decodeSuccesses = if (isH264) videoPacketsCount else playerStats.decodeSuccessCount,
            decodeFailures = playerStats.decodeFailureCount,
            lastDecodeError = playerStats.lastError ?: "None",
            lastFrameFirst4BytesHex = if (playerStats.lastHex4.isNotEmpty()) playerStats.lastHex4 else "--",
            lastFrameEndsEoi = playerStats.lastEndsEoi,
            decodedBitmapSize = effectiveResolution,
            fps = effectiveFps,
            decodeTimeMs = playerStats.decodeTimeMsAvg.toLong(),
            decodeTimeMsAvg = playerStats.decodeTimeMsAvg,
            decodeTimeMsMax = playerStats.decodeTimeMsMax,
            frameAgeMs = playerStats.frameAgeMs,
            arrivalIntervalP95Ms = playerStats.arrivalIntervalP95Ms,
            droppedFrames = playerStats.droppedFrames,
            rttAvgMs = rttAvgMs,
            rttP95Ms = rttP95Ms,
            audioUnderrunCount = underruns,
            frameSizeBytes = effectiveFrameSize,
            statusDetail = statusDetailMessage,
            videoCodec = activeVideoCodec
        )
    }

    fun release() {
        disconnect()
        mjpegPlayer.release()
    }
}

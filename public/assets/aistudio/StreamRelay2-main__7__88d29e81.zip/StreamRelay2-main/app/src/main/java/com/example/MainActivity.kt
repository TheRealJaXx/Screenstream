package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.AppMode
import com.example.ui.CaptureViewModel
import com.example.ui.LatencyTestScreen
import com.example.ui.ModeSelectionScreen
import com.example.ui.RoundTripScreen
import com.example.ui.RxScreen
import com.example.ui.TxScreen
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {

  private val viewModel: CaptureViewModel by viewModels()

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    setContent {
      MyApplicationTheme {
        val currentMode by viewModel.currentMode.collectAsStateWithLifecycle()

        val multiplePermissionLauncher = rememberLauncherForActivityResult(
          contract = ActivityResultContracts.RequestMultiplePermissions()
        ) { result ->
          if (result[Manifest.permission.RECORD_AUDIO] == true) {
            viewModel.onAudioPermissionGranted()
          }
        }

        LaunchedEffect(currentMode) {
          if (currentMode == AppMode.TX || currentMode == AppMode.ROUND_TRIP) {
            val cameraGranted = ContextCompat.checkSelfPermission(
              this@MainActivity,
              Manifest.permission.CAMERA
            ) == PackageManager.PERMISSION_GRANTED

            val audioGranted = ContextCompat.checkSelfPermission(
              this@MainActivity,
              Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED

            if (audioGranted && currentMode == AppMode.TX) {
              viewModel.onAudioPermissionGranted()
            }

            val needPermissions = mutableListOf<String>()
            if (!cameraGranted) needPermissions.add(Manifest.permission.CAMERA)
            if (!audioGranted) needPermissions.add(Manifest.permission.RECORD_AUDIO)

            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
              val notifGranted = ContextCompat.checkSelfPermission(
                this@MainActivity,
                Manifest.permission.POST_NOTIFICATIONS
              ) == PackageManager.PERMISSION_GRANTED
              if (!notifGranted) needPermissions.add(Manifest.permission.POST_NOTIFICATIONS)
            }

            if (needPermissions.isNotEmpty()) {
              multiplePermissionLauncher.launch(needPermissions.toTypedArray())
            }
          }
        }

        // Back button returns to role selection if inside TX or RX
        BackHandler(enabled = currentMode != AppMode.UNSELECTED) {
          viewModel.selectMode(AppMode.UNSELECTED)
        }

        Surface(modifier = Modifier.fillMaxSize()) {
          when (currentMode) {
            AppMode.UNSELECTED -> {
              ModeSelectionScreen(
                onSelectMode = { mode -> viewModel.selectMode(mode) }
              )
            }
            AppMode.TX -> {
              TxScreen(
                viewModel = viewModel,
                onChangeMode = { viewModel.selectMode(AppMode.UNSELECTED) }
              )
            }
            AppMode.RX -> {
              RxScreen(
                viewModel = viewModel,
                onChangeMode = { viewModel.selectMode(AppMode.UNSELECTED) }
              )
            }
            AppMode.TEST_TX -> {
              LatencyTestScreen(
                viewModel = viewModel,
                onChangeMode = { viewModel.selectMode(AppMode.UNSELECTED) }
              )
            }
            AppMode.ROUND_TRIP -> {
              RoundTripScreen(
                viewModel = viewModel,
                onChangeMode = { viewModel.selectMode(AppMode.UNSELECTED) }
              )
            }
          }
        }
      }
    }
  }
}
